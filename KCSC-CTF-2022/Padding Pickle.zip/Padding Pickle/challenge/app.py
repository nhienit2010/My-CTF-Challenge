from flask import *
from database import *
from security import *
import config
import pickle
import base64
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = config.SECRET_KEY
db = Database("database.db")
security = Security()

@app.route('/')
def index():
    if "username" not in session:
        return redirect(url_for("login"))
    return redirect(url_for("dashboard"))

@app.route('/dashboard')
def dashboard():
    if "username" not in session:
        return redirect(url_for("login")) 
    
    token = request.args.get("token")
    if not token:
        return render_template("dashboard.html", is_admin=False)
    else:
        try:
            role, username =security.decrypt(token)
        except Exception as e:
            return render_template_string(str(e))

        try:
            if session["username"] != username.decode():
                return render_template_string("Token username not same with session username")

            if role == security.admin_role:
                return render_template("dashboard.html", is_admin=True)
            else:
                return render_template("dashboard.html", is_admin=False)
        except:
            return render_template_string("Something went wrong")
    
    return redirect(url_for("dashboard"))

@app.route('/login', methods=['GET','POST'])
def login():
    if "username" in session:
        return redirect(url_for("dashboard"))

    if request.method != "POST":
        return render_template("login.html")
    else:
        username = request.form["username"]
        password = request.form["password"]

        if (len(username) > 0 and len(password) > 0):
            db_instance = db.get_instance()
            db_cursor = db_instance.cursor()
            result = db_cursor.execute("SELECT * FROM users where username=? and password=?", (username, password)).fetchall()

            if (len(result) > 0):
                session["username"] = username
            else:
                return render_template_string("User not exists")
            
            db_instance = db.get_instance()
            db_cursor = db_instance.cursor()
            db_cursor.execute("INSERT INTO log(username, token) VALUES(?, ?)", (username, security.encrypt(username)))
            
            return redirect(url_for("dashboard", token=security.encrypt(username)))
        else:
            render_template_string("Data not blank")

@app.route('/register', methods=['GET','POST'])
def register():
    if "username" in session:
        return redirect(url_for("dashboard"))
    
    if request.method != "POST":
        return render_template("register.html")
    else:
        username = request.form["username"]
        password = request.form["password"]

        if (len(username) > 0 and len(password) > 0):
            db_instance = db.get_instance()
            db_cursor = db_instance.cursor()
            result = db_cursor.execute("SELECT * FROM users where username=?", (username, )).fetchall()

            if (len(result) > 0):
                return render_template_string("User existed")
            else:
                db_cursor.execute("INSERT INTO users(username, password) VALUES(?, ?)", (username, password, ))
                render_template_string("User was created")

            return redirect(url_for("login"))
        else:
            render_template_string("Data not blank")

@app.route('/log', methods=['GET'])
def log():
    db_instance = db.get_instance()
    db_cursor = db_instance.cursor()
    result = db_cursor.execute("SELECT * FROM log").fetchall()

    if len(result) > 0:
        return render_template("log.html", data=result)
    else:
        return render_template_string("Log is empty")

@app.route('/api/admin_pickle', methods=['POST'])
def admin_pickle():
    if "username" not in session:
        return redirect(url_for("login"))

    pickled = request.form['pickle']
    if len(pickled) > 0:
        data = base64.urlsafe_b64decode(pickled)
        pickle.loads(data)

    return render_template_string("I recieved, but can you RCE me?")


if __name__ == '__main__':
    # Create log for admin user with admin's role
    db_instance = db.get_instance()
    db_cursor = db_instance.cursor()
    db_cursor.execute("INSERT INTO log VALUES(?, ?, ?)", (1, "admin", security.encrypt("admin", security.admin_role)))
    
    # Run server
    app.run("0.0.0.0", 1337)