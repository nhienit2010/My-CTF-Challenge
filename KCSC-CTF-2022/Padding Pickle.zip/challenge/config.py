from os import urandom

SECRET_KEY = "SuperSecretKeyStoreInEnviromentVariable"
ADMIN_ROLE = b"W1z4rd"
KEY = urandom(16)