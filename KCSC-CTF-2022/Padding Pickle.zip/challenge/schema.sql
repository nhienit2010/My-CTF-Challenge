PRAGMA case_sensitive_like=ON; 

DROP TABLE IF EXISTS users;
CREATE TABLE IF NOT EXISTS users (
    id          INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    username    VARCHAR(255) NOT NULL,
    password    VARCHAR(255) NOT NULL
);
INSERT INTO users VALUES (1, "admin", "admin");

DROP TABLE IF EXISTS log;
CREATE TABLE IF NOT EXISTS log (
    id          INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    username	VARCHAR(255) NOT NULL,
    token       VARCHAR(255) NOT NULL
);
