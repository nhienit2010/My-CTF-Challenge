from Crypto.Cipher import AES
import os
import base64
from database import *
import config

class Security:
    def __init__(self):
        self.admin_role = config.ADMIN_ROLE # Hidden variable
        self.key = config.KEY # Hidden variable, random key 16 bytes  

    def pad(self, msg, blksize):
        tmp = blksize - (len(msg) % blksize)
        return msg + bytes([tmp]*tmp)

    def unpad(self, msg, blksize):
        assert len(msg) != 0, "Zero-length input cannot be unpadded"
        assert len(msg) % blksize == 0, "Input data is not padded"
        length = msg[-1] # get pad length
        msg, p = msg[:-length], msg[-length:]
        assert all([i == length for i in p]), "PKCS#7 padding is incorrect."
        return msg

    def encrypt(self, username, role=b"MuGGl3"):
        iv = os.urandom(16) # random IV
        token = self.pad(role + b"|" + username.encode(), 16)
        cipher = AES.new(self.key, AES.MODE_CBC, iv)
        token = iv + cipher.encrypt(token)
        return base64.b64encode(token)

    def decrypt(self, token):
        token = base64.b64decode(token)
        iv, ct = token[:16], token[16:]
        cipher = AES.new(self.key, AES.MODE_CBC, iv)
        role, username = self.unpad(cipher.decrypt(ct),16).split(b"|")
        return role, username