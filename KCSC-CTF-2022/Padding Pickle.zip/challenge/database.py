import sqlite3

class Database:
	def __init__(self, file_name):
		self._conn = sqlite3.connect(file_name, check_same_thread=False)
		with open('schema.sql') as f:
			self._conn.executescript(f.read())

	def get_instance(self):
		return self._conn
