<?php

require 'config.php';

session_unset();

header("Location: index.php");
?>