<?php
// Real flag
// FLAG = KCSC{real_flag};

?>

KCSC{k0_l4m_M4_d01_co_4n_H4???????x1337}
<!-- 
fake flag :)) i am trolling you 
real flag inside php code of flag.php
-->